const othermenu = (prefix) => { 
	return `
╔══✪〘 OTHER 〙✪══
║
╠➥ *${prefix}sticker*
╠➥ *${prefix}stickergif*
╠➥ *${prefix}ttp [teks]*
╠➥ *${prefix}toimg [replay sticker]*
╠➥ *${prefix}neko*
╠➥ *${prefix}pokemon*
╠➥ *${prefix}inu*
╠➥ *${prefix}infoGempa*
╠➥ *${prefix}quotes*
╠➥ *${prefix}dadu*
╠➥ *${prefix}quotes*
╠➥ *${prefix}thunder [teks]*
╠➥ *${prefix}nulis [teks]*
╠➥ *${prefix}ocr [gambar]*
╠➥ *${prefix}meme*
╠➥ *${prefix}memindo*
╠➥ *${prefix}testime*
╠➥ *${prefix}ttp [teks]*
╠➥ *${prefix}hobby*
╠➥ *${prefix}beritahoax*
╠➥ *${prefix}watak*
╠➥ *${prefix}jsholat [daerah]*
╠➥ *${prefix}report*
╠➥ *${prefix}hilih [teks]*
╠➥ *${prefix}cekjodoh* [nama]
╠➥ *${prefix}artinama* [rizky]
╠➥ *${prefix}listsurah*
╠➥ *${prefix}zodiak [zodiak kamu]*
╠➥ *${prefix}listzodiak*
║
╠═══✪〘 ANIMALS 〙✪══
║
╠➥ *${prefix}unta*
╠➥ *${prefix}elang*
╠➥ *${prefix}anjing*
╠➥ *${prefix}randomcat*
║
╚═〘 YOKS BOT 〙`
}
exports.othermenu = othermenu